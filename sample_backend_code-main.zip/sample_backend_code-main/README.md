cd into respective directories for the backend codes
